EVEN_INSTUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_INSTUCTION = 'What is the result of the expresion?'
GCD_INSTUCTION = 'Find the greatest common divisor of given numbers.'
PROGRSSION_INSTUCTION = 'What number is missing in the progression?'
PRIME_INSTUCTION = 'Answer "yes" if given number is prime.' \
                    ' Otherwise answer"no".'
MATH_SIGNS = ('+', '-', '*')
AMOUNT_OF_ROUND = 3
MIN_PROGR_LENGHT, MAX_PROGR_LENGHT = 5, 10