import random

from brain_games.consts import PRIME_INSTUCTION
from brain_games.engine import run_game


def is_prime(number):
    count = 2
    number_sqrt = int(number ** 0.5)

    while count < number_sqrt:
        return number_sqrt % 2 == 0
    count += 1


def get_num_and_prime_ans():
    number_question = random.randint(1, 100)

    result = 'yes' if is_prime(number_question) else 'no'

    return number_question, result


def run_game_prime():
    run_game(get_num_and_prime_ans, PRIME_INSTUCTION)
