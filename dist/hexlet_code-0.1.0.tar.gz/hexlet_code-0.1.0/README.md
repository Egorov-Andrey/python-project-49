### Hexlet tests and linter status:
[![Actions Status](https://github.com/Egorov-Andrey/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Egorov-Andrey/python-project-49/actions)

### Quality Gate Status 

[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Bugs

[![Bugs](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=bugs)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Code smells

[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Duplicated Lines (%)

[![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=duplicated_lines_density)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Lines of Code

[![Lines of Code](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=ncloc)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Reliability Rating

[![Reliability Rating](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=reliability_rating)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Security Rating

[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=security_rating)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Technical Debt

[![Technical Debt](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=sqale_index)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Maintainability Rating

[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=sqale_rating)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)

### Vulnerabilities

[![Vulnerabilities](https://sonarcloud.io/api/project_badges/measure?project=Egorov-Andrey_python-project-49&metric=vulnerabilities)](https://sonarcloud.io/summary/new_code?id=Egorov-Andrey_python-project-49)


### Asciinema - brain-games

https://asciinema.org/a/BuAa2DkaWyyTJxsqVDF3RA7iK

